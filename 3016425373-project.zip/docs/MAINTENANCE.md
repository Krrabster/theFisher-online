# Pravidla údržby projektu

Projekt obsahuje lokalizační data, herní XML a obrazové/zvukové podklady. Textové konfigurační soubory jsou součástí formátu hry; jejich klíče, sekce a zástupné značky proto berte jako rozhraní, ne jako volný text.

## Formát textových dat

- V přiřazovacích řádcích používejte jeden formát: `klic = hodnota`; prázdnou hodnotu zapisujte jako `klic =` bez koncové mezery.
- Zachovávejte pořadí záznamů, názvy klíčů, ID, hlavičky sekcí a kódování souboru.
- Neměňte zástupné značky jako `{0}`, `[FISHID]` nebo `[CNT]`, HTML/XML značky jako `<color>` ani escapované `\n` bez ověření ve hře.
- Texty v `Books/` jsou próza, nikoli seznam klíčů. Neformátujte je automaticky.
- XML soubory nepřevádějte hromadně formátovačem. Bílá místa v elementech s textem mohou být součástí hodnot a struktura se může lišit podle očekávání hry.

## Barevné konvence

Barvy přidělujte podle významu a zachovávejte výjimky, které označují herní klasifikaci.

| Použití | Barva |
|---|---|
| Kategorie a běžné technické popisky | `#FFB74D` |
| Balíčky a názvy sad | `#40C4FF` |
| Osobní informace | `#42A5F5` |
| Úspěch, získání nebo možnost prodeje | `#69F0AE` nebo `#81C784` |
| Upozornění a nebezpečné akce | `#EF5350` nebo `#FF5252` |
| Vzácnost, měna a důležitý štítek úkolu | `#FFD700` |
| Dynamické hodnoty a proměnné v úkolech | `#C900FF` |

V `maps.txt` je zeměpisná část názvu lokace tlumeně červená (`#EF5350`) a název lokace zlatý (`#FFD700`). Barvy druhů a vlastností ryb v `fishLang.txt` jsou klasifikační; nesjednocujte je na jednu barvu.

## Duplicity a klíče

- Klíč musí být jedinečný uvnitř své sekce. Stejný klíč v jiné sekci může být záměrný, pokud hra sekce rozlišuje.
- Shodné opakované definice odstraňte. Konfliktní hodnoty nemažte bez ověření významu a chování načítání.
- ID úkolů v `QTask.xml` se opakují pod různými kategoriemi (`cat id`); jde o různé úkolové skupiny, proto je tato duplicita zachována.
- Klíče `*_Name` se v `maps.txt` mohou opakovat mezi `[MAP_NAMES]` a `[LOC_NAMES]`; sekce tvoří samostatné jmenné prostory.

Při této revizi byly textové duplicity uklizeny takto:

- `InterfaceLang.txt`: u kolidujících klíčů zůstala pozdější definice; u identických opakování jediná kopie. Zachované hodnoty zahrnují `post_msg8 = {0} Ti daroval {1} x{2}`, `boat_inf6 = [U] Stát na lodi`, formát zkušeností `{3:2}` a `arw_appl = Žádost`.
- `fishLang.txt`: identické opakované názvy byly sloučeny. U `378_latn` zůstalo `Boreogadus saida`, které odpovídá českému názvu „Treska polární“; konflikt s `Gadus chalcogrammus` byl odstraněn. U `141_name` a `414_name` zůstala pozdější definice.
- V `WpnLang.xml` zůstávají duplicitní `weapon id` 1043, 1268, 1269 a 1408. Jejich záznamy mají rozdílný obsah nebo je jeden prázdný; před opravou je nutné zjistit, zda jde o nechtěné kolize ID, alternativní záznamy nebo záměrné přepisy.

## Rozsah revize

Při poslední revizi nebyly ve pracovním adresáři dostupné složky `Books/`, `Quests/` a `Sound/`; jejich obsah proto nebyl zahrnut do formátování ani kontroly klíčů.
