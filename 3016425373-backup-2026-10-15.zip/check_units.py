import re

with open('WpnLang.xml', 'r', encoding='utf-8') as f:
    text = f.read()

sm_matches = re.findall(r'(\b\d+\s*Sm\b|"Sm")', text, re.IGNORECASE)
print('Sm matches:', len(sm_matches), sm_matches[:10])

gr_matches = re.findall(r'(\b\d+[.,]?\d*\s*Gr\b)', text, re.IGNORECASE)
print('Gr matches:', len(gr_matches), gr_matches[:10])

