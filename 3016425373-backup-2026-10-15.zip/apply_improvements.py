import re
import xml.etree.ElementTree as ET

def update_interface_lang():
    path = "InterfaceLang.txt"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    replacements = {
        # Cyrillic fixes
        'act_infactout=Vyzvednutí Shift+Е': 'act_infactout=Vyzvednutí Shift+E',
        'act_infact=Zmáčkni Е': 'act_infact=Stiskni E',
        'invn_rec2={0} X{1} Шт': 'invn_rec2={0} x{1} ks',
        'wpn_line3=Tloušťka (Мм): {0}': 'wpn_line3=Tloušťka (mm): {0}',
        'wpn_chair1=Obnovení Energie Při Sezení: {0}/Сек': 'wpn_chair1=Obnovení energie při sezení: {0}/s',
        'post_1=От: {0} Written{1}\\nSubject: {2}': 'post_1=Od: {0} Napsáno: {1}\\nPředmět: {2}',
        'post_msg8={0} Ti Daroval {1} Х{2}': 'post_msg8={0} ti daroval {1} x{2}',
        'cht_msg5=Aukce: Prodáno {0} Х{1} Ks': 'cht_msg5=Aukce: Prodáno {0} x{1} ks',
        'wpn_bait_inf_6=Jigging Spoon-Baits Require Jig Guiding Or Step-By-Step Guiding. Сarnivore Mostly Attacks At The Moment The Lure Hits The Bottom': 'wpn_bait_inf_6=Jigovací plandavky vyžadují jigové nebo skokové vedení. Dravec útočí většinou v okamžiku, kdy nástraha dopadne na dno.',

        # English to Czech UI
        'gi_uinf_0=Level: {0}    Time Online: {1}': 'gi_uinf_0=Úroveň: {0}    Čas online: {1}',
        'gi_uinf_5=Health: {0}/{1}': 'gi_uinf_5=Zdraví: {0}/{1}',
        'gi_uinf_6=Radresistense: {0}/{1}': 'gi_uinf_6=Odolnost vůči radiaci: {0}/{1}',
        'gi_uinf_7=Stamina: {0}/{1}': 'gi_uinf_7=Výdrž: {0}/{1}',
        'gi_nl0=Health +{0}\\n': 'gi_nl0=Zdraví +{0}\\n',
        'inv_bonus=Effects On Wearing:': 'inv_bonus=Efekty při nošení:',
        'exitmsg_2=Exit To Characters Select Screen?': 'exitmsg_2=Odejít do výběru postav?',
        'hlp4=Left Mouse Button: Reel In The Line': 'hlp4=Levé tlačítko myši (LMB): Navíjení vlasce',
        'hlp5=Middle Mouse Button: Recast The Bait To The Previous Point, As For The Spinning - Take The': 'hlp5=Prostřední tlačítko myši (MMB): Znovu nahodit na předchozí místo; u přívlače – vzít nástrahu',
        'hlp6=Turn On/Off The Flashlight': 'hlp6=Zapnout/vypnout svítilnu',
        'hlp7=Sit On/Get Up From The Chair (If You Have One)': 'hlp7=Sednout / vstát z křesla (pokud ho máte)',
        'hlp8=To Throw An Attractant For The Float Tackle (If It Is Equipped In The Slot)': 'hlp8=Vhodit návnadu pro lov na splávek (pokud je vložena ve slotu)',
        'hlp9=Turn Left/Right': 'hlp9=Otočit vlevo/vpravo',
        'hlp13=Set The Movement Destination Point': 'hlp13=Nastavit cílový bod pohybu',
        'msg_other=Too Close!': 'msg_other=Příliš blízko!',
        'cht_msg38=Naučil Se Tuto Dovednost \'{0}\' {1} Level': 'cht_msg38=Naučil se dovednost \'{0}\' úroveň {1}',
        "silence=<color='#FF5252'>Moderator Mute You. Left {0} Min.</color>": "silence=<color='#FF5252'>Moderátor vás ztišil. Zbývá {0} min.</color>",
        'selpersbtn=Level: {0}': 'selpersbtn=Úroveň: {0}',
        'newletter=To Send Messages, Your Character Must Up Level 5': 'newletter=Pro odesílání zpráv musí vaše postava dosáhnout úrovně 5',
        "fishdrop_1=<color='#FFA726'>The Fish Got Away</color>": "fishdrop_1=<color='#FFA726'>Ryba unikla</color>",
        "fishdrop_2=<color='#FFA726'>The Fish Used All The Line</color>": "fishdrop_2=<color='#FFA726'>Ryba vymotala všechen vlasec</color>",
        "inv_pers=<color='#00E5FF'>Bound</color>": "inv_pers=<color='#00E5FF'>Vázané</color>",
        "inv_wpers=<color='#00E5FF'>Will Be Bound</color>": "inv_wpers=<color='#00E5FF'>Bude vázáno</color>",
        "inv_impr=<color='#26A69A'>Upgradable</color>": "inv_impr=<color='#26A69A'>Vylepšitelné</color>",
        'inv_useeff=Effects Of Usage:': 'inv_useeff=Efekty při použití:',
        'inv_effectinf={0} On {1}': 'inv_effectinf={0} na {1}',
        'cnt_energ=Energy Consumption On Casting: {0}': 'cnt_energ=Spotřeba energie při náhozu: {0}',
        "wpn_drop=<color='#FFA726'>Item </color>{0}<color='#FFA726'> Is Lost</color>": "wpn_drop=<color='#FFA726'>Předmět {0} byl ztracen</color>",
        'chnam2=Character’s Name Is Allowed To Use': 'chnam2=Jméno postavy je povoleno',
        'fshop_msg2={0} Ks. Of Total Weight {1}\\nCurrent Cost For 1 Kilo Is {2}\\n\\nTotal Sale Value Of This Species Will Be\\n': 'fshop_msg2={0} ks o celkové hmotnosti {1}\\nAktuální cena za 1 kg je {2}\\n\\nCelková prodejní cena tohoto druhu bude\\n',
        'inv_aukcinf=Nejnižší Cena: {0} \\nBoard Lots With This Price: {1}': 'inv_aukcinf=Nejnižší cena: {0} \\nNabídky s touto cenou: {1}',
        'gi_frac_i=Fraction \\"{0}\\": {1}': 'gi_frac_i=Frakce \\"{0}\\": {1}',
        'crft_wpnpr=Source Item': 'crft_wpnpr=Zdrojový předmět',
        'wpn_onlym=Male': 'wpn_onlym=Muž',
        'wpn_onlyw=Female': 'wpn_onlyw=Žena',
        'wpn_catfly=Cívka: {0:0.0} M (On Using Cord 1 Mm)': 'wpn_catfly=Cívka: {0:0.0} m (při použití šňůry 1 mm)',
        'prov_prov_9=Walk The Dog': 'prov_prov_9=Vedení nástrahy „Walk the Dog“',
        'help_info_keys=[1-2-3] Otevřít Nebo Vzít Prut\\n[Backspace] Remove Rod\\n[Y] Set Rod To Ground\\n[Q] Smartphone\\n[Space] Jump': '[1-2-3] Otevřít nebo vzít prut\\n[Backspace] Uložit prut\\n[Y] Položit prut na zem\\n[Q] Smartphone\\n[Mezerník] Skok',
        'wpn_bait_inf_7=Wobblers Give Their Best During Slow Guiding But The Best Option Will Be The Using Of Twitching Guiding': 'wpn_bait_inf_7=Woblery fungují nejlépe při pomalém vedení, ale ideální volbou je použití twitchingu (škubavého vedení)',
    }

    count = 0
    for old_k, new_k in replacements.items():
        if old_k in content:
            content = content.replace(old_k, new_k)
            count += 1
        else:
            print(f"Warning: could not find key in InterfaceLang: {old_k[:30]}")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"InterfaceLang.txt updated: replaced {count} strings")

def update_guide():
    path = "guide.txt"
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    updated = []
    for line in lines:
        if line.startswith("string_startText="):
            updated.append("string_startText=Srdečné přivítání od týmu Fisher Online!\\nChcete-li rychleji dokončit výukový kurz základních herních mechanismů, postupujte podle pokynů ve vyskakovacím okně.\\nOkno nápovědy můžete kdykoli otevřít stisknutím klávesy <color='#FFD700'>[F1]</color> a získat tak přehled o nejdůležitějších ovládacích prvcích.\n")
        elif line.startswith("string_finishText="):
            updated.append("string_finishText=Tým Fisher Online vám přeje hodně zábavy při hraní. Petrův zdar!\n")
        elif line.startswith("string_0="):
            updated.append("string_0=Klávesami <color='#FFD700'>[WASD]</color> přejděte k vodě. V noci vám může pomoci svítilna (klávesa <color='#FFD700'>[P]</color>).\n")
        elif line.startswith("string_1="):
            updated.append("string_1=Stisknutím kláves <color='#FFD700'>[1]</color>, <color='#FFD700'>[2]</color> nebo <color='#FFD700'>[3]</color> vezměte rybářský prut do ruky.\n")
        elif line.startswith("string_2="):
            updated.append("string_2=Pojďme ještě chvíli trénovat! Chyťte další rybu. Chcete-li použít držák prutu, stiskněte klávesu <color='#FFD700'>[Y]</color>.\n")
        elif line.startswith("string_3="):
            updated.append("string_3=Rybářský prut nahoďte levým tlačítkem myši <color='#FFD700'>[LMB]</color>. Chcete-li použít stojan na prut, stiskněte klávesu <color='#FFD700'>[Y]</color>.\n")
        elif line.startswith("string_4="):
            updated.append("string_4=Stisknutím klávesy <color='#FFD700'>[ALT]</color> skryjete kurzor myši a přepnete do herního režimu.\n")
        elif line.startswith("string_5="):
            updated.append("string_5=Počkejte, až ryba zabere. Chcete-li zvětšit nebo zmenšit oblast sledování, stiskněte klávesu <color='#FFD700'>[Z]</color>.\n")
        elif line.startswith("string_6="):
            updated.append("string_6=Záběr!\\nPodržte pravé tlačítko myši <color='#FFD700'>[RMB]</color>, abyste rybu zasekli!\n")
        elif line.startswith("string_7="):
            updated.append("string_7=Rybu se nepodařilo zaseknout.\n")
        elif line.startswith("string_8="):
            updated.append("string_8=Držte levé tlačítko myši <color='#FFD700'>[LMB]</color>, abyste rybu přitáhli.\n")
        elif line.startswith("string_9="):
            updated.append("string_9=Vezměte si rybu, nebo ji pusťte zpět do vody.\n")
        elif line.startswith("string_10="):
            updated.append("string_10=Chcete-li interagovat s rybářským prutem na stojanu, namiřte pohled na rukojeť prutu a postupujte podle pokynů značky interakce.\n")
        else:
            updated.append(line)

    with open(path, "w", encoding="utf-8") as f:
        f.writelines(updated)
    print("guide.txt updated successfully")

def update_wpn_units():
    path = "WpnLang.xml"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    # Fix Russian "Sm" unit to "cm"
    content = content.replace('Maximální Hloubka Rybolovu "Sm"', 'Maximální hloubka rybolovu (cm)')
    # Fix Gr to g
    content = re.sub(r'(\d+)\s*Gr\b', r'\1 g', content)
    content = re.sub(r'(\d+,\d+)\s*Gr\b', r'\1 g', content)

    # Validate XML
    ET.fromstring(content)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("WpnLang.xml units updated successfully")

def update_hints():
    path = "Hints.txt"
    content = "[HINTS]\n\nhint=Různé ryby preferují různá místa. Experimentujte s lokací, hloubkou a návnadou.\nhint2=Větší háček může pomoci ulovit větší rybu, ale obvykle snižuje počet záběrů.\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Hints.txt updated successfully")

if __name__ == "__main__":
    update_interface_lang()
    update_guide()
    update_wpn_units()
    update_hints()

