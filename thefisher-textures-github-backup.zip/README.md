# theFisher Online texture changes

This backup contains all texture files changed in this session. Overlay these files onto the game's `theFisher_Data/StreamingAssets/Textures` directory to restore the edited assets. Filenames, extensions, and original dimensions are preserved.

## Changes

- `NoImage.png` (56x56 PNG): photorealistic pike placeholder.
- `Fish/-1.png` (512x256 PNG): common carp.
- `Fish/0.png` (512x256 PNG): brown trout.
- `Bases/*.png` (36 location thumbnails, each 512x256 PNG): regenerated according to the game's English map names in `Localization/English/maps.txt`.

The 76 `Bases/Back*.jpg` files were not changed because they are already 1920x1080.
